package com.rodrilang.librarymanager.integrations.tiendanube.controller;

import com.rodrilang.librarymanager.integrations.tiendanube.dto.response.TiendanubeAuthorizationResponse;
import com.rodrilang.librarymanager.integrations.tiendanube.dto.response.TiendanubeConnectionStatusResponse;
import com.rodrilang.librarymanager.integrations.tiendanube.service.TiendanubeOAuthService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;

@Tag(name = "Tiendanube - Autenticación", description = "Vinculación y autenticación de cuentas de Tiendanube")
@RestController
@RequestMapping("/api/integrations/tiendanube")
@RequiredArgsConstructor
public class TiendanubeAuthController {

    private final TiendanubeOAuthService tiendanubeOAuthService;

    @Value("${app.frontend-url}")
    private String frontendUrl;

    @GetMapping("/status")
    public TiendanubeConnectionStatusResponse getStatus() {
        return tiendanubeOAuthService.getStatus();
    }

    @GetMapping("/authorization-url")
    public ResponseEntity<TiendanubeAuthorizationResponse> getAuthorizationUrl() {
        return ResponseEntity.ok(tiendanubeOAuthService.createAuthorizationUrl());
    }

    @GetMapping("/oauth/callback")
    public ResponseEntity<Void> callback(@RequestParam String code,
                                         @RequestParam String state
    ) {
        tiendanubeOAuthService.handleCallback(code, state);

        URI redirectUri = URI.create(frontendUrl + "/settings/integrations/tiendanube" + "?connected=true");

        return ResponseEntity
                .status(HttpStatus.FOUND)
                .location(redirectUri)
                .build();
    }

    @DeleteMapping("/disconnect")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void disconnect() {
        tiendanubeOAuthService.disconnect();
    }
}