package com.rodrilang.librarymanager.integrations.tiendanube.service;

import com.rodrilang.librarymanager.integrations.tiendanube.dto.response.TiendanubeInventoryStatusResponse;
import com.rodrilang.librarymanager.integrations.tiendanube.dto.response.TiendanubeProductLinkResponse;
import com.rodrilang.librarymanager.integrations.tiendanube.dto.response.TiendanubePublishResultResponse;
import com.rodrilang.librarymanager.integrations.tiendanube.dto.response.TiendanubeRemoteProductResponse;
import com.rodrilang.librarymanager.integrations.tiendanube.dto.response.TiendanubeRetryResponse;

import java.util.List;

public interface TiendanubeProductService {

    TiendanubePublishResultResponse publishInventory(Long inventoryId);

    List<TiendanubeRemoteProductResponse> getRemoteProducts();

    TiendanubeProductLinkResponse linkExistingProduct(Long inventoryId, Long productId, Long variantId);

    TiendanubeRetryResponse retry(Long inventoryId);

    TiendanubeInventoryStatusResponse getInventoryStatus(Long inventoryId);

    void unlinkInventory(Long inventoryId);

    void deletePublication(Long inventoryId);
}
