package com.rodrilang.librarymanager.controller;

import com.rodrilang.librarymanager.dto.request.BookCatalogFilterRequest;
import com.rodrilang.librarymanager.dto.request.BookRequest;
import com.rodrilang.librarymanager.dto.request.LookupBookByIsbnRequest;
import com.rodrilang.librarymanager.dto.request.UpdateBookRequest;
import com.rodrilang.librarymanager.dto.response.BookDetailResponse;
import com.rodrilang.librarymanager.dto.response.BookSummaryResponse;
import com.rodrilang.librarymanager.dto.response.PageResponse;
import com.rodrilang.librarymanager.service.BookService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
@Tag(name = "Libros", description = "Gestión del catálogo de libros")
public class BookController {

    private final BookService bookService;

    @PostMapping
    public ResponseEntity<BookDetailResponse> create(
            @Valid @RequestBody BookRequest request
    ) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(bookService.create(request));
    }

    @PostMapping("/lookup")
    public ResponseEntity<BookDetailResponse> lookupByIsbn(
            @Valid @RequestBody LookupBookByIsbnRequest request
    ) {
        return ResponseEntity.ok(
                bookService.lookupByIsbn(request.isbn())
        );
    }

    @GetMapping
    public ResponseEntity<PageResponse<BookSummaryResponse>> getAll(
            @ParameterObject
            BookCatalogFilterRequest filters,
            @RequestParam(defaultValue = "false")
            boolean force,
            @ParameterObject
            @PageableDefault(
                    size = 20,
                    sort = "title"
            )
            Pageable pageable
    ) {
        return ResponseEntity.ok(
                PageResponse.of(
                        bookService.findCatalog(
                                filters.toCriteria(force),
                                pageable
                        )
                )
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookDetailResponse> getById(
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(
                bookService.getById(id)
        );
    }

    @GetMapping("/isbn/{isbn}")
    public ResponseEntity<BookDetailResponse> getByIsbn(
            @PathVariable String isbn
    ) {
        return ResponseEntity.ok(
                bookService.getByIsbn(isbn)
        );
    }

    @Deprecated
    @GetMapping("/search")
    public ResponseEntity<PageResponse<BookSummaryResponse>> search(
            @RequestParam String q,
            @RequestParam(defaultValue = "false")
            boolean force,
            @ParameterObject
            @PageableDefault(size = 20)
            Pageable pageable
    ) {
        return ResponseEntity.ok(
                PageResponse.of(bookService.search(q, force, pageable))
        );
    }

    @PutMapping("/{bookId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BookDetailResponse> update(
            @PathVariable Long bookId,
            @Valid @RequestBody UpdateBookRequest request
    ) {
        return ResponseEntity.ok(
                bookService.update(bookId, request)
        );
    }
}
