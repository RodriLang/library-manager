package com.rodrilang.librarymanager.auth.security.config;

import jakarta.servlet.DispatcherType;
import com.rodrilang.librarymanager.auth.security.filter.JwtAuthenticationFilter;
import com.rodrilang.librarymanager.admin.audit.filter.AdminAuditFilter;
import com.rodrilang.librarymanager.auth.security.handler.JwtAuthenticationEntryPoint;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfigurationSource;

import static org.springframework.security.config.Customizer.withDefaults;
import static org.springframework.security.config.http.SessionCreationPolicy.STATELESS;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;
    private final AdminAuditFilter adminAuditFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http,
            CorsConfigurationSource corsConfigurationSource,
            DaoAuthenticationProvider daoAuthenticationProvider
    ) throws Exception {

        return http
                /*
                 * Actualmente se usan tokens enviados explícitamente
                 * en Authorization y no cookies de autenticación.
                 */
                .csrf(AbstractHttpConfigurer::disable)

                .cors(withDefaults())

                .authenticationProvider(daoAuthenticationProvider)

                .authorizeHttpRequests(auth -> auth
                        .dispatcherTypeMatchers(
                                DispatcherType.ASYNC,
                                DispatcherType.ERROR
                        ).permitAll()

                        .requestMatchers(
                                "/api/auth/login",
                                "/api/auth/refresh",
                                "/api/auth/forgot-password",
                                "/api/auth/reset-password",
                                "/api/integrations/tiendanube/oauth/callback",
                                "/api/store/payments/mercado-pago/oauth/callback"
                        ).permitAll()

                        .requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html").permitAll()
                        .requestMatchers("/actuator/health", "/actuator/health/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/auth/invitations/**").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/auth/invitations/*/register").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/integrations/tiendanube/webhooks").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/storefront/**").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/storefront/*/checkout").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/storefront/*/shipping/quotes").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/storefront/payments/mercado-pago/webhook").permitAll()
                        .anyRequest().authenticated()
                )

                .sessionManagement(manager ->
                        manager.sessionCreationPolicy(STATELESS)
                )

                .exceptionHandling(exception ->
                        exception.authenticationEntryPoint(
                                jwtAuthenticationEntryPoint
                        )
                )

                .formLogin(AbstractHttpConfigurer::disable)
                .httpBasic(AbstractHttpConfigurer::disable)
                .logout(AbstractHttpConfigurer::disable)

                .addFilterBefore(
                        jwtAuthenticationFilter,
                        UsernamePasswordAuthenticationFilter.class
                )
                .addFilterAfter(
                        adminAuditFilter,
                        JwtAuthenticationFilter.class
                )

                .build();
    }

    @Bean
    public DaoAuthenticationProvider daoAuthenticationProvider(
            UserDetailsService userDetailsService,
            PasswordEncoder passwordEncoder
    ) {
        DaoAuthenticationProvider provider =
                new DaoAuthenticationProvider(userDetailsService);

        provider.setPasswordEncoder(passwordEncoder);

        return provider;
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration authenticationConfiguration
    ) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}