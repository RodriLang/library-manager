package com.rodrilang.librarymanager.fiscal.controller;

import com.rodrilang.librarymanager.fiscal.dto.request.IssueCreditNoteRequest;
import com.rodrilang.librarymanager.fiscal.dto.request.IssueInvoiceRequest;
import com.rodrilang.librarymanager.fiscal.dto.response.FiscalDocumentResponse;
import com.rodrilang.librarymanager.fiscal.model.FiscalDocumentStatus;
import com.rodrilang.librarymanager.fiscal.model.FiscalDocumentType;
import com.rodrilang.librarymanager.fiscal.service.FiscalDocumentService;
import com.rodrilang.librarymanager.fiscal.service.FiscalPdfService;
import com.rodrilang.librarymanager.fiscal.service.FiscalTicketService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Tag(name = "Facturación", description = "Emisión y consulta de comprobantes fiscales asociados a ventas")
public class FiscalDocumentController {

    private final FiscalDocumentService documentService;
    private final FiscalPdfService pdfService;
    private final FiscalTicketService ticketService;

    @PostMapping("/sales/{saleId}/invoice")
    public ResponseEntity<FiscalDocumentResponse> issueInvoice(
            @PathVariable Long saleId,
            @Valid @RequestBody IssueInvoiceRequest request
    ) {
        return ResponseEntity.ok(documentService.issueInvoice(saleId, request));
    }

    @GetMapping("/sales/{saleId}/invoice")
    public ResponseEntity<FiscalDocumentResponse> findInvoice(
            @PathVariable Long saleId
    ) {
        return documentService.findBySaleId(saleId)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/sales/{saleId}/fiscal-documents")
    public ResponseEntity<List<FiscalDocumentResponse>> findSaleDocuments(
            @PathVariable Long saleId
    ) {
        return ResponseEntity.ok(documentService.findAllBySaleId(saleId));
    }

    @GetMapping("/fiscal-documents")
    public ResponseEntity<Page<FiscalDocumentResponse>> findAll(
            @RequestParam(required = false) FiscalDocumentType documentType,
            @RequestParam(required = false) FiscalDocumentStatus status,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            Pageable pageable
    ) {
        return ResponseEntity.ok(
                documentService.findAll(documentType, status, from, to, pageable)
        );
    }

    @GetMapping("/fiscal-documents/{documentId}")
    public ResponseEntity<FiscalDocumentResponse> findById(
            @PathVariable Long documentId
    ) {
        return ResponseEntity.ok(documentService.findById(documentId));
    }

    @PostMapping("/fiscal-documents/{invoiceId}/credit-note")
    public ResponseEntity<FiscalDocumentResponse> issueCreditNote(
            @PathVariable Long invoiceId,
            @Valid @RequestBody IssueCreditNoteRequest request
    ) {
        return ResponseEntity.ok(documentService.issueCreditNote(invoiceId, request));
    }

    @PostMapping("/fiscal-documents/{documentId}/reconcile")
    public ResponseEntity<FiscalDocumentResponse> reconcile(
            @PathVariable Long documentId
    ) {
        return ResponseEntity.ok(documentService.reconcile(documentId));
    }

    @GetMapping(
            value = "/fiscal-documents/{documentId}/pdf",
            produces = MediaType.APPLICATION_PDF_VALUE
    )
    public ResponseEntity<byte[]> pdf(
            @PathVariable Long documentId
    ) {
        byte[] pdf = pdfService.generate(documentId);
        FiscalDocumentResponse document = documentService.findById(documentId);
        String prefix = document.documentType() == FiscalDocumentType.CREDIT_NOTE
                ? "nota-credito-"
                : "factura-";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentDisposition(
                ContentDisposition.inline()
                        .filename(prefix + documentId + ".pdf")
                        .build()
        );

        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdf);
    }
    @GetMapping(value = "/fiscal-documents/{documentId}/ticket", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> ticket(
            @PathVariable Long documentId,
            @RequestParam(defaultValue = "false") boolean autoPrint
    ) {
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_HTML)
                .body(ticketService.generate(documentId, autoPrint));
    }

}
