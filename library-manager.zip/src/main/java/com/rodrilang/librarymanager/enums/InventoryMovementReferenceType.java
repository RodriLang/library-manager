package com.rodrilang.librarymanager.enums;

public enum InventoryMovementReferenceType {

    INVENTORY_ENTRY,
    SALE,
    PURCHASE,
    TIENDANUBE_ORDER,
    STOCK_ADJUSTMENT,
    INVENTORY_COUNT,
    GOODS_RECEIPT,
    STORE_RETURN
}