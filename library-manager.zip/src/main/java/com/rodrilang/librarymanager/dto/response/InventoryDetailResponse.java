package com.rodrilang.librarymanager.dto.response;

import com.rodrilang.librarymanager.enums.BookCondition;
import com.rodrilang.librarymanager.integrations.tiendanube.enums.TiendanubeInventoryStatus;
import com.rodrilang.librarymanager.inventory.pricing.model.InventoryPriceSource;
import com.rodrilang.librarymanager.purchasing.preference.dto.response.PreferredProviderResponse;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

public record InventoryDetailResponse(
        Long id,
        BookDetailResponse book,
        PreferredProviderResponse preferredProvider,
        Integer stock,
        Integer minimumStock,
        Integer consignmentStock,
        Integer ownedStock,
        Long consignmentProviderId,
        String consignmentProviderName,
        BookCondition condition,
        BigDecimal salePrice,
        LocalDate currentPriceEffectiveFrom,
        InventoryPriceSource currentPriceSource,
        Long currentPriceImportId,
        Long currentPriceImportProviderId,
        String currentPriceImportProviderName,
        String currentPriceImportSourceName,
        String currentPriceImportFilename,
        Long currentPriceLastConfirmedImportId,
        Long currentPriceLastConfirmedProviderId,
        String currentPriceLastConfirmedProviderName,
        String currentPriceLastConfirmedImportSourceName,
        String currentPriceLastConfirmedImportFilename,
        LocalDate currentPriceLastConfirmedAt,
        String currentPriceLastConfirmedSource,
        BigDecimal nextSalePrice,
        LocalDate nextPriceEffectiveFrom,
        LocalDate lastPriceCheckedAt,
        Boolean tiendanubePriceSyncEnabled,
        TiendanubeInventoryStatus tiendanubeStatus,
        Boolean active,
        Instant createdAt,
        Instant updatedAt
) {
}
